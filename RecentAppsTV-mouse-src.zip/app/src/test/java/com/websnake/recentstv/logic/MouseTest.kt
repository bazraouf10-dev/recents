package com.websnake.recentstv.logic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 1.11 — the mouse drives the same state machine as the remote. */
class MouseTest {

    private val a = TaskRef(11, "app.a")
    private val b = TaskRef(12, "app.b")
    private val c = TaskRef(13, "app.c")

    // items: [#killall, app.a, app.b, app.c]
    private fun ready() = Overlay.loaded(OvState(), listOf(a, b, c), emptyList(), true, false)
    private fun press(s: OvState, btn: Btn) = Overlay.key(s, KeyIn(btn, true))
    private fun release(s: OvState, btn: Btn) = Overlay.key(s, KeyIn(btn, false))

    @Test fun `hover moves the focus and marks it as the mouse's`() {
        val s = Overlay.focusAt(ready(), 3)
        assertEquals(3, s.focus); assertTrue(s.byPointer); assertEquals(Item.Task(c), s.focusedItem)
    }

    @Test fun `hover over the gear pill focuses the gear, over Kill All does not`() {
        val g = Overlay.focusAt(ready(), 0, gear = true)
        assertTrue(g.gearFocused); assertEquals(Item.Settings, g.focusedItem)
        val k = Overlay.focusAt(g, 0, gear = false)
        assertFalse(k.gearFocused); assertEquals(Item.KillAll, k.focusedItem)
        assertFalse(Overlay.focusAt(ready(), 2, gear = true).gearFocused)      // the gear belongs to Kill All only
    }

    @Test fun `hover ignores indexes that are not in the row`() {
        val s = ready()
        assertEquals(s, Overlay.focusAt(s, 9)); assertEquals(s, Overlay.focusAt(s, -1))
    }

    @Test fun `hover is ignored while a button is held, a menu is open, or the row is busy`() {
        val held = press(Overlay.focusAt(ready(), 1), Btn.OK).first
        assertTrue(held.pressing); assertEquals(1, Overlay.focusAt(held, 3).focus)
        val menu = Overlay.holdElapsed(held)
        assertEquals(1, Overlay.focusAt(menu, 3).focus)
        assertEquals(1, Overlay.focusAt(ready().copy(busy = true, focus = 1), 3).focus)
        assertEquals(1, Overlay.focusAt(ready().copy(flying = "app.a", focus = 1), 3).focus)
    }

    @Test fun `click on a card opens it, like OK`() {
        val hovered = Overlay.focusAt(ready(), 2)
        val (down, e1) = press(hovered, Btn.OK)
        assertTrue(down.pressing); assertEquals(listOf<Effect>(Effect.ArmHold), e1)
        val (up, e2) = release(down, Btn.OK)
        assertEquals("app.b", up.selecting); assertEquals(listOf<Effect>(Effect.Switch("app.b", 12)), e2)
    }

    @Test fun `a long press opens the menu and its release neither opens nor closes anything`() {
        val menu = Overlay.holdElapsed(press(Overlay.focusAt(ready(), 2), Btn.OK).first)
        assertEquals("app.b", menu.ctxPkg)
        val (after, effects) = release(menu, Btn.OK)
        assertEquals("app.b", after.ctxPkg); assertTrue(effects.isEmpty()); assertNull(after.selecting)
    }

    @Test fun `middle click opens the menu of that card`() {
        val s = Overlay.menuAt(ready(), 3)
        assertEquals("app.c", s.ctxPkg); assertEquals(0, s.ctxSel); assertEquals(3, s.focus)
        assertEquals(ready(), Overlay.menuAt(ready(), 0).copy(byPointer = false, focus = 1))   // Kill All has no menu
    }

    @Test fun `menu rows follow the pointer, clamped, and a click runs the row`() {
        val menu = Overlay.menuAt(ready(), 2)
        assertEquals(2, Overlay.ctxSelect(menu, 2).ctxSel)
        assertEquals(3, Overlay.ctxSelect(menu, 99).ctxSel); assertEquals(0, Overlay.ctxSelect(menu, -4).ctxSel)
        assertEquals(0, Overlay.ctxSelect(ready(), 2).ctxSel)                       // no menu: nothing
        val (ran, effects) = press(Overlay.ctxSelect(menu, 0), Btn.OK)               // row 0 = Pin to row
        assertEquals(listOf<Effect>(Effect.SetPin("app.b", true)), effects); assertNull(ran.ctxPkg)
        val (rel, relEffects) = release(ran, Btn.OK)                                 // the release must not open the app
        assertTrue(relEffects.isEmpty()); assertNull(rel.selecting)
    }

    @Test fun `a click outside the open menu closes only the menu`() {
        val (s, effects) = press(Overlay.menuAt(ready(), 2), Btn.BACK)
        assertNull(s.ctxPkg); assertFalse(s.closing); assertTrue(effects.isEmpty())
    }

    @Test fun `the gear pill opens Settings`() {
        val g = Overlay.focusAt(ready(), 0, gear = true)
        val (d, _) = press(g, Btn.OK)
        assertEquals(listOf<Effect>(Effect.OpenSettings), release(d, Btn.OK).second)
    }
}
