package com.websnake.recentstv.ui.overlay

import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.input.pointer.pointerInput

/**
 * 1.11 — what the mouse can do on the overlay. The Activity implements it by feeding the same state machine the
 * remote uses (`Overlay`), so a click behaves exactly like OK, a middle click like ↑, the wheel like ← / →.
 * [index] is the item's logical position ([com.websnake.recentstv.logic.OvState.items]); [gear] marks the ⚙ pill
 * above Kill All.
 */
class OverlayPointer(
    val hover: (index: Int, gear: Boolean) -> Unit = { _, _ -> },
    /** Primary button (or a touch) went down / up on an item. */
    val press: (index: Int, gear: Boolean, down: Boolean) -> Unit = { _, _, _ -> },
    /** Middle button on an item: its menu. */
    val menuAt: (index: Int) -> Unit = {},
    /** Wheel / touchpad scroll, in Compose's sign convention (positive y = down, positive x = right). */
    val wheel: (dx: Float, dy: Float) -> Unit = { _, _ -> },
    /** Primary button down / up on the empty backdrop. */
    val backdrop: (down: Boolean) -> Unit = {},
    /** Mouse over a row of the open menu (rows count from the card up). */
    val menuHover: (row: Int) -> Unit = {},
    val menuPress: (row: Int, down: Boolean) -> Unit = { _, _ -> },
    val menuWheel: (dy: Float) -> Unit = {},
) {
    companion object { val None = OverlayPointer() }
}

/**
 * Pointer handling for one target. Lambdas are read once (the input block is not restarted), so they must read
 * changing values through State objects, not capture them.
 *
 * - hover (mouse Enter / Move, button not held) → [onHover]
 * - primary button (any touch) down → [onPress]`(true)`; up, or the gesture ending any other way → `(false)`
 * - middle button → [onMiddle]
 * - wheel → [onWheel]
 *
 * The secondary (right) button is left alone: Android turns it into Back, which the overlay already handles.
 */
fun Modifier.pointerTarget(
    onHover: () -> Unit = {},
    onPress: (down: Boolean) -> Unit = {},
    onMiddle: () -> Unit = {},
    onWheel: (dx: Float, dy: Float) -> Unit = { _, _ -> },
): Modifier = pointerInput(Unit) {
    awaitPointerEventScope {
        var down = false
        while (true) {
            val e = awaitPointerEvent()
            val c = e.changes.firstOrNull() ?: continue
            when (e.type) {
                PointerEventType.Enter, PointerEventType.Move ->
                    if (!down && c.type == PointerType.Mouse) onHover()
                PointerEventType.Press -> when {
                    down -> {}
                    c.type == PointerType.Mouse && e.buttons.isTertiaryPressed -> onMiddle()
                    c.type != PointerType.Mouse || e.buttons.isPrimaryPressed -> { down = true; onPress(true) }
                }
                PointerEventType.Scroll -> { onWheel(c.scrollDelta.x, c.scrollDelta.y); c.consume() }
                else -> {}
            }
            // released, or cancelled (a touch taken over, the window lost): never leave a press hanging
            val held = if (c.type == PointerType.Mouse) e.buttons.isPrimaryPressed else c.pressed
            if (down && !held) { down = false; onPress(false) }
        }
    }
}
