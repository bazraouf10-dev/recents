package com.websnake.recentstv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * 1.11 — the "Recents Button" launcher entry: turns the floating button on or off. The first time it sends you to
 * "Display over other apps" for this app (on a TV without that screen: `adb shell appops set <package> SYSTEM_ALERT_WINDOW allow`).
 */
class FloatingButtonActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when {
            !Settings.canDrawOverlays(this) -> {
                Toast.makeText(this, R.string.floating_button_permission, Toast.LENGTH_LONG).show()
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(this, "adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow", Toast.LENGTH_LONG).show()
                }
            }
            FloatingButtonService.running -> {
                stopService(Intent(this, FloatingButtonService::class.java))
                Toast.makeText(this, R.string.floating_button_off, Toast.LENGTH_SHORT).show()
            }
            else -> {
                val i = Intent(this, FloatingButtonService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, R.string.floating_button_on, Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
