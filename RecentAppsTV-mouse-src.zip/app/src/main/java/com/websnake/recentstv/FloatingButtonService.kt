package com.websnake.recentstv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.ServiceCompat
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * 1.11 — a small floating button over every app. A tap (or a mouse click) opens the overlay, the same intent the
 * shortcut uses, so it toggles; drag it to move it (the spot is remembered). Needs "Display over other apps".
 * Started and stopped by [FloatingButtonActivity].
 */
class FloatingButtonService : Service() {

    private var wm: WindowManager? = null
    private var button: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (button == null) {
            if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
            goForeground()
            addButton()
            running = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        button?.let { runCatching { wm?.removeView(it) } }
        button = null
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.floating_button_label), NotificationManager.IMPORTANCE_MIN)
            )
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this))
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(getString(R.string.floating_button_label))
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
        )
    }

    private fun addButton() {
        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        val density = resources.displayMetrics.density
        val size = (SIZE_DP * density).roundToInt()
        val pad = (10 * density).roundToInt()

        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(170, 20, 20, 28)) }
            alpha = 0.8f
            contentDescription = getString(R.string.shortcut_recents_long)
        }
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val lp = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(KEY_X, (16 * density).roundToInt())
            y = prefs.getInt(KEY_Y, (96 * density).roundToInt())
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (moved || abs(dx) > slop || abs(dy) > slop) {
                        moved = true
                        lp.x = startX + dx.roundToInt(); lp.y = startY + dy.roundToInt()
                        runCatching { manager.updateViewLayout(view, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putInt(KEY_X, lp.x).putInt(KEY_Y, lp.y).apply() else openRecents()
                }
            }
            true
        }
        runCatching { manager.addView(view, lp) }.onSuccess { button = view }.onFailure { stopSelf() }
    }

    private fun openRecents() {
        val open = Intent(ShortcutActivity.ACTION_OPEN).setClassName(packageName, "$packageName.RecentsActivity")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(open) }
    }

    companion object {
        @Volatile var running = false
        private const val SIZE_DP = 52
        private const val CHANNEL = "floating_button"
        private const val NOTIFICATION_ID = 11
        private const val PREFS = "floating_button"
        private const val KEY_X = "x"
        private const val KEY_Y = "y"
    }
}
